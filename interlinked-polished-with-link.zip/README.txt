Interlinked — Final polished project showcase with upload link

Added:
- real upload link inside the site
- upload button in navigation and hero
- clickable center node
- live link shown in the About section

Upload page:
https://projection-project.vercel.app/upload

Open:
1. Unzip
2. Open index.html

Deploy:
Upload the whole folder to Vercel, Netlify, or GitHub Pages.
